export { default } from './VueIconButton.vue';
export { default as VueIconButton } from './VueIconButton.vue';