import VueProgress from './VueProgress.vue';
export { VueProgress };