import VueCheckbox from './VueCheckbox.vue';
import type { CheckboxProps as VueCheckboxProps } from '../core/_Checkbox';

export { VueCheckbox };
export type { VueCheckboxProps };
