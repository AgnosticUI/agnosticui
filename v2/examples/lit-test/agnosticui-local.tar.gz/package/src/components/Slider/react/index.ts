export { ReactSlider } from './ReactSlider';
export type { ReactSliderProps } from './ReactSlider';
