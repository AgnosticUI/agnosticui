import VueButtonFx from './VueButtonFx.vue';
import type { ButtonFxProps as VueButtonFxProps } from '../core/_ButtonFx';

export { VueButtonFx };
export type { VueButtonFxProps };
