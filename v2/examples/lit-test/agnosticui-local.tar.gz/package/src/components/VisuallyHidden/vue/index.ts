import VueVisuallyHidden from './VueVisuallyHidden.vue';

export { VueVisuallyHidden };
