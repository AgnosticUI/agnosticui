import VueFieldset from './VueFieldset.vue';
import type { FieldsetProps as VueFieldsetProps } from '../core/_Fieldset';

export { VueFieldset, type VueFieldsetProps };
