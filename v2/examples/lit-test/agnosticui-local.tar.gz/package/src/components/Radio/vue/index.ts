import VueRadio from './VueRadio.vue';
import type { RadioProps as VueRadioProps } from '../core/_Radio';

export { VueRadio };
export type { VueRadioProps };
