import VueLoader from './VueLoader.vue';
import type { LoaderProps as VueLoaderProps } from '../core/_Loader';

export { VueLoader, type VueLoaderProps };
