import VueEmptyState from './VueEmptyState.vue';
import type { EmptyStateProps as VueEmptyStateProps } from '../core/_EmptyState';

export { VueEmptyState, type VueEmptyStateProps };
