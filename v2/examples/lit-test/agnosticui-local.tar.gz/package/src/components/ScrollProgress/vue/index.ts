import VueScrollProgress from './VueScrollProgress.vue';
export { VueScrollProgress };
