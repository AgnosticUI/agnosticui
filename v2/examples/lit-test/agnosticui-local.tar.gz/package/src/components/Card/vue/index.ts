import VueCard from './VueCard.vue';
import type { CardProps as VueCardProps } from '../core/_Card';

export { VueCard, type VueCardProps };
