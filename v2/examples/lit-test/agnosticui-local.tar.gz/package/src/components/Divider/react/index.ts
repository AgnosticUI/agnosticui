export { ReactDivider } from './ReactDivider';
export type { ReactDividerProps } from './ReactDivider';
