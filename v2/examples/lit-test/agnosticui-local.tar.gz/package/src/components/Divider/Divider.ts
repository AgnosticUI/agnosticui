export { AgDivider } from './core/_Divider';
export type { DividerProps, DividerJustify, DividerSize, DividerVariant } from './core/_Divider';
