import VueDivider from './VueDivider.vue';
import type { DividerProps as VueDividerProps } from '../core/_Divider';

export { VueDivider };
export type { VueDividerProps };
