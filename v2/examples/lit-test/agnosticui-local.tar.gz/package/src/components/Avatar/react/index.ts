export { ReactAvatar, ReactAvatarGroup } from './ReactAvatar';
export type { ReactAvatarProps, ReactAvatarGroupProps } from './ReactAvatar';
