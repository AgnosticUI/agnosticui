export { default } from './VueAlert.vue';
export { default as VueAlert } from './VueAlert.vue';
export type { AlertProps as VueAlertProps } from '../core/_Alert';
