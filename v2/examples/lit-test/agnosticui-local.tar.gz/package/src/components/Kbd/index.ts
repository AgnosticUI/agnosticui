export { AgKbd, type KbdProps, type KbdVariant, type KbdSize } from './core/Kbd';
// Backward compatibility alias
export { AgKbd as Kbd } from './core/Kbd';
