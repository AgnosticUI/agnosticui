import VueKbd from './VueKbd.vue';
import type { KbdProps as VueKbdProps } from '../core/_Kbd';

export { VueKbd, type VueKbdProps };
