export { ReactBadge } from './ReactBadge';
export type { ReactBadgeProps } from './ReactBadge';
