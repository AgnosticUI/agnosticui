import VueMessageBubble from './VueMessageBubble.vue';
import type { MessageBubbleProps as VueMessageBubbleProps } from '../core/_MessageBubble';

export { VueMessageBubble };
export type { VueMessageBubbleProps };