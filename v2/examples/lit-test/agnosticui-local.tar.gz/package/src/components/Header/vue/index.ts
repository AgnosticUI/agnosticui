export { default } from './VueHeader.vue';
export { default as VueHeader } from './VueHeader.vue';
export type { HeaderProps as VueHeaderProps } from '../core/_Header';
