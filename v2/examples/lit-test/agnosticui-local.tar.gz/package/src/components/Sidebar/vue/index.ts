export { default } from './VueSidebar.vue';
export { default as VueSidebar } from './VueSidebar.vue';
