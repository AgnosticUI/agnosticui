// v2/lib/src/components/Timeline/react/index.ts
export { ReactTimeline, ReactTimelineItem } from './Timeline.js';
export type { ReactTimelineProps, ReactTimelineItemProps } from './Timeline.js';
