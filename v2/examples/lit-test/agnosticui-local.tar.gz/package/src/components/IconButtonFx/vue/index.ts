import VueIconButtonFx from './VueIconButtonFx.vue';
import type { IconButtonFxProps as VueIconButtonFxProps } from '../core/_IconButtonFx';

export { VueIconButtonFx };
export type { VueIconButtonFxProps };
