import VueSpinner from './VueSpinner.vue';
import type { SpinnerProps as VueSpinnerProps } from '../core/_Spinner';

export { VueSpinner, type VueSpinnerProps };
