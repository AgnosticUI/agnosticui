import VueAspectRatio from './VueAspectRatio.vue';

export { VueAspectRatio };
