export { ReactCollapsible, type ReactCollapsibleProps } from './ReactCollapsible';
