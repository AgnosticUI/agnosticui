import VueCollapsible from './VueCollapsible.vue';
import type { CollapsibleProps as VueCollapsibleProps } from '../core/_Collapsible';

export { VueCollapsible };
export type { VueCollapsibleProps };
