import VueMark from './VueMark.vue';
import type { MarkProps as VueMarkProps } from '../core/_Mark';

export { VueMark };
export type { VueMarkProps };