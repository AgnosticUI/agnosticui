export { default as VueSelect } from './VueSelect.vue';
