# Button Component Specification

*Single source of truth for all AgnosticUI v2 Button implementation decisions*

## Component Overview

The Button component provides an accessible, almost headless implementation of interactive buttons following WAI-ARIA APG patterns. It serves as the foundation for user actions with comprehensive variant support, loading states, and flexible content.

## AI-First Design Goals

- **Canonical Pattern**: Immutable `_Button.ts` with experimental `Button.ts`
- **AI Extensibility**: Clear patterns for AI-driven modifications and styling
- **Minimalist & Themeable**: Functional CSS only, completely styleable externally
- **Foundation Component**: Base pattern for other interactive components

## Architecture

### Core Component
- `AgButton` - Comprehensive Lit-based button component with variant and state support

### File Structure
```
src/components/Button/
   core/
      _Button.ts              # Canonical, upgrade-safe source
      _Button.spec.ts         # Comprehensive test suite
   react/
      ReactButton.tsx        # React wrapper component
      ReactButton.spec.tsx   # React-specific tests
   vue/
      VueButton.vue          # Vue 3 wrapper component
      VueButton.spec.ts      # Vue-specific tests
   spec.md                    # This specification
```

## Functional Requirements

### Visual Variants
- `primary` - Primary brand action (filled)
- `secondary` - Secondary action (outlined/subtle)
- `danger` - Destructive action (red)
- `ghost` - Minimal styling (transparent)

### Size Variants
- `sm` - Small (compact layouts)
- `md` - Medium (default)
- `lg` - Large (prominent actions)

### Button Types
- `button` - Standard button (default)
- `submit` - Form submission
- `reset` - Form reset

### States
- `disabled` - Non-interactive state
- `loading` - Shows loading indicator, disables interaction
- `pressed` - Toggle state for toggle buttons

### Content Support
- **Text Content**: Primary button content
- **Icon Support**: Leading/trailing icons via slots
- **Loading Indicator**: Built-in loading state with customizable spinner

## WAI-ARIA APG Compliance (MANDATORY)

### Required Accessibility Features
- **Semantic Button**: Uses proper `<button>` element
- **Keyboard Navigation**: Space/Enter activation
- **Focus Management**: Visible focus indicator
- **State Communication**: Disabled and loading states properly announced
- **Screen Reader**: Clear content announcement

### ARIA Attributes
- `aria-disabled` - For disabled state (preserves focusability)
- `aria-pressed` - For toggle buttons (true/false/undefined)
- `aria-busy` - For loading state
- `aria-label` - When button contains only icons

### Keyboard Interaction
- `Space` - Activates the button
- `Enter` - Activates the button
- `Tab` - Moves focus to/from button

## Design Token Integration

### Core Styling Principles
- **Contrast-Aware Hovers**: Dark backgrounds get darker, light backgrounds get lighter
- **High-Contrast Focus**: Always use `--ag-focus` (blue) for maximum contrast
- **Semantic Colors**: Use brand tokens for consistent theming

### Variant Token Mapping
```css
/* PRIMARY VARIANT */
--button-primary-bg: var(--ag-primary);
--button-primary-color: var(--ag-on-primary);
--button-primary-hover: var(--ag-primary-hover); /* Darker */

/* SECONDARY VARIANT */
--button-secondary-bg: var(--ag-background-secondary);
--button-secondary-color: var(--ag-text-primary);
--button-secondary-hover: var(--ag-background-tertiary); /* Lighter */

/* DANGER VARIANT */
--button-danger-bg: var(--ag-danger);
--button-danger-color: var(--ag-on-danger);
--button-danger-hover: var(--ag-danger-hover); /* Darker */

/* GHOST VARIANT */
--button-ghost-bg: transparent;
--button-ghost-color: var(--ag-text-primary);
--button-ghost-hover: var(--ag-background-secondary); /* Subtle */
```

### Custom Properties
```css
/* Size Control */
--button-height: var(--ag-space-12, 3rem);
--button-padding-x: var(--ag-space-4, 1rem);
--button-padding-y: var(--ag-space-3, 0.75rem);

/* Typography */
--button-font-size: var(--ag-text-base, 1rem);
--button-font-weight: var(--ag-font-medium, 500);

/* Border and Spacing */
--button-radius: var(--ag-radius-sm, 0.25rem);
--button-border-width: var(--ag-border-width, 1px);

/* Focus */
--button-focus-ring: var(--ag-focus);
--button-focus-width: var(--ag-focus-width, 2px);
--button-focus-offset: var(--ag-focus-offset, 2px);
```

## Usage Patterns

### Basic Button
```html
<ag-button>Click me</ag-button>
```

### Primary Action
```html
<ag-button variant="primary">Save Changes</ag-button>
```

### Button with Icon
```html
<ag-button variant="primary">
  <lucide-save slot="icon-left"></lucide-save>
  Save
</ag-button>
```

### Loading State
```html
<ag-button loading disabled>
  Saving...
</ag-button>
```

### Form Submission
```html
<ag-button type="submit" variant="primary">
  Submit Form
</ag-button>
```

### Destructive Action
```html
<ag-button variant="danger">
  Delete Account
</ag-button>
```

## Framework Integration

### React Wrapper
- **Component**: `ReactButton`
- **Props**: TypeScript interfaces for all properties
- **Events**: Standard React onClick handlers
- **Ref Support**: Forward refs to underlying web component

### Vue Wrapper
- **Component**: `VueButton`
- **Props**: Vue 3 Composition API support
- **Events**: Vue event system integration
- **Reactivity**: Full reactive property binding

## Testing Requirements

### Unit Tests
-  Variant rendering (primary, secondary, danger, ghost)
-  Size variants (sm, md, lg)
-  State management (disabled, loading, pressed)
-  Button types (button, submit, reset)
-  Accessibility attributes
-  Keyboard interaction
-  Event dispatching
-  Icon slot rendering
-  Loading state behavior

### Integration Tests
-  React wrapper functionality
-  Vue wrapper functionality
-  Form integration
-  Cross-framework consistency

### Accessibility Tests
-  Screen reader announcement
-  Keyboard navigation
-  Focus management
-  State communication
-  Color contrast validation

## Quality Assurance

### Current Status
- **Implementation**: Complete with comprehensive feature set
- **Testing**: Full test coverage across all variants
- **Framework Support**: React, Vue wrappers implemented
- **Accessibility**: WAI-ARIA compliant
- **Playground**: Interactive demos available

### Hover State Implementation
Follows AgnosticUI v2 contrast-aware pattern:
- **Colored buttons** (primary, danger): Background darkens on hover
- **Light buttons** (secondary, ghost): Background lightens on hover
- **Focus rings**: Always high-contrast blue (`--ag-focus`)

### Known Limitations
- Icon positioning limited to left/right slots (by design for simplicity)
- Custom loading spinner requires slot override
- No built-in tooltip integration (use separate Tooltip component)

## External References

- [WAI-ARIA APG Button Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/button/)
- [MDN Button Element](https://developer.mozilla.org/en-US/docs/Web/HTML/Element/button)
- [Web Content Accessibility Guidelines](https://www.w3.org/WAI/WCAG21/Understanding/focus-visible.html)

## Changelog

### v2.0.0-dev (Current)
-  Initial implementation with full feature set
-  Framework wrappers for React, Vue
-  Comprehensive test coverage
-  Almost headless styling approach
-  Design token integration
-  Contrast-aware hover patterns
-  Loading state with accessibility
-  Icon slot support
-  Form integration