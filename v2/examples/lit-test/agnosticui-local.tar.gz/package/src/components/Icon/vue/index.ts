import VueIcon from './VueIcon.vue';
import type { IconProps } from '../core/_Icon';

export { VueIcon };
export type { IconProps as VueIconProps };
