export { ReactIcon } from './ReactIcon';
export type { ReactIconProps } from './ReactIcon';
