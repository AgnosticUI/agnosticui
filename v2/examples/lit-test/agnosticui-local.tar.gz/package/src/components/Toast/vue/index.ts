import VueToast from './VueToast.vue';
import type { ToastProps as VueToastProps } from '../core/Toast';

export { VueToast };
export type { VueToastProps };
