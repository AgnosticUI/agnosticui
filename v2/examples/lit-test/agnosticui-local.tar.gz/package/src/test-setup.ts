import '@testing-library/jest-dom';

// Global test setup for React Testing Library and jest-dom matchers